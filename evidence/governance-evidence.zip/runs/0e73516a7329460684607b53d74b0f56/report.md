# Maritime run 0e73516a7329460684607b53d74b0f56

Status: SUCCESS

Public port activity; synthetic shipments and counterfactuals. Activity deviation is not measured waiting time.

## run_id

```json
"0e73516a7329460684607b53d74b0f56"
```

## environment

```json
"local"
```

## version

```json
"0.1.0"
```

## start_time

```json
"2026-10-10T09:06:28.625762+00:00"
```

## status

```json
"SUCCESS"
```

## stage_status

```json
{
  "bronze": "PASS",
  "silver": "PASS",
  "gold": "PASS",
  "intelligence": "PASS",
  "scenario": "PASS",
  "decision": "PASS"
}
```

## source_status

```json
[
  {
    "source_id": "wpi",
    "status": "NOT_CONFIGURED",
    "record_count": 0,
    "source_name": "NGA World Port Index",
    "source_url": "https://msi.nga.mil/Publications/WPI",
    "schema_version": "1",
    "classification": "OBSERVED",
    "dataset_version": null,
    "run_id": "0e73516a7329460684607b53d74b0f56"
  },
  {
    "source_id": "unlocode",
    "status": "NOT_CONFIGURED",
    "record_count": 0,
    "source_name": "UNECE UN/LOCODE",
    "source_url": "https://unlocode.unece.org/publications/",
    "schema_version": "2025-1",
    "classification": "OBSERVED",
    "dataset_version": null,
    "run_id": "0e73516a7329460684607b53d74b0f56"
  },
  {
    "source_id": "routes",
    "status": "NOT_CONFIGURED",
    "record_count": 0,
    "source_name": "Operator supplied public maritime route geometry",
    "source_url": null,
    "schema_version": "1",
    "classification": "DERIVED",
    "dataset_version": null,
    "run_id": "0e73516a7329460684607b53d74b0f56"
  },
  {
    "source_id": "weather",
    "status": "SUCCESS",
    "record_count": 36,
    "source_name": "Open-Meteo ERA5 historical reanalysis",
    "source_url": "https://archive-api.open-meteo.com/v1/archive",
    "schema_version": "1",
    "classification": "DERIVED",
    "dataset_version": null,
    "run_id": "0e73516a7329460684607b53d74b0f56"
  },
  {
    "acquisition_id": "da7f6ce6a1028c144a15c829",
    "request_parameters": {
      "f": "json",
      "where": "portname IN ('Singapore','Rotterdam','Shanghai','Los Angeles-Long Beach','New York-New Jersey','Jebel Ali')",
      "returnCountOnly": "true"
    },
    "response_status": 200,
    "duplicate_payload": false,
    "source_timestamp": "Fri, 18 Sep 2026 14:33:46 GMT",
    "source_id": "portwatch_ports",
    "source_url": "https://services9.arcgis.com/weJ1QsnbMYJlCHdG/arcgis/rest/services/PortWatch_ports_database/FeatureServer/0/query?f=json&where=portname+IN+%28%27Singapore%27%2C%27Rotterdam%27%2C%27Shanghai%27%2C%27Los+Angeles-Long+Beach%27%2C%27New+York-New+Jersey%27%2C%27Jebel+Ali%27%29&returnCountOnly=true",
    "retrieved_at": "2026-10-10T09:06:15.356601+00:00",
    "checksum": "393bab7fa38f3421806e4942676bb181aee9b07ba87103cf13ebfeab1562fa8b",
    "raw_path": "data\\governance-final-20261010\\bronze\\portwatch_ports\\393bab7fa38f3421806e4942676bb181aee9b07ba87103cf13ebfeab1562fa8b.raw",
    "bytes": 13,
    "duration_seconds": 0.22999619995243847,
    "retries": 0,
    "status": "SUCCESS",
    "dataset_version": "sd1201_-802421151",
    "record_count": 0,
    "expected_extract_count": 6,
    "source_name": "IMF PortWatch ports",
    "schema_version": "1",
    "classification": "OBSERVED",
    "run_id": "0e73516a7329460684607b53d74b0f56"
  },
  {
    "acquisition_id": "8b22e67e2bb00ae4beb89171",
    "request_parameters": {
      "f": "json",
      "where": "portname IN ('Singapore','Rotterdam','Shanghai','Los Angeles-Long Beach','New York-New Jersey','Jebel Ali')",
      "outFields": "*",
      "returnGeometry": "false",
      "orderByFields": "ObjectId",
      "resultOffset": 0,
      "resultRecordCount": 1000
    },
    "response_status": 200,
    "duplicate_payload": false,
    "source_timestamp": "Fri, 18 Sep 2026 14:33:46 GMT",
    "source_id": "portwatch_ports",
    "source_url": "https://services9.arcgis.com/weJ1QsnbMYJlCHdG/arcgis/rest/services/PortWatch_ports_database/FeatureServer/0/query?f=json&where=portname+IN+%28%27Singapore%27%2C%27Rotterdam%27%2C%27Shanghai%27%2C%27Los+Angeles-Long+Beach%27%2C%27New+York-New+Jersey%27%2C%27Jebel+Ali%27%29&outFields=%2A&returnGeometry=false&orderByFields=ObjectId&resultOffset=0&resultRecordCount=1000",
    "retrieved_at": "2026-10-10T09:06:15.451134+00:00",
    "checksum": "1c44bc66f5f1dcc8e724ad3eb28534fe0fa28da7178eea4851f42c36f8da2ed9",
    "raw_path": "data\\governance-final-20261010\\bronze\\portwatch_ports\\1c44bc66f5f1dcc8e724ad3eb28534fe0fa28da7178eea4851f42c36f8da2ed9.raw",
    "bytes": 7659,
    "duration_seconds": 0.09428089996799827,
    "retries": 0,
    "status": "SUCCESS",
    "dataset_version": "sd1201_-802421151",
    "record_count": 6,
    "source_name": "IMF PortWatch ports",
    "schema_version": "1",
    "classification": "OBSERVED",
    "run_id": "0e73516a7329460684607b53d74b0f56"
  },
  {
    "acquisition_id": "a7ca82d949c5de86bf001492",
    "request_parameters": {
      "f": "json",
      "where": "portid IN ('port1188','port744','port815','port1114','port664','port1201') AND date >= DATE '2026-02-12' AND date <= DATE '2026-10-10'",
      "returnCountOnly": "true"
    },
    "response_status": 200,
    "duplicate_payload": false,
    "source_timestamp": "Tue, 06 Oct 2026 18:41:27 GMT",
    "source_id": "portwatch_activity",
    "source_url": "https://services9.arcgis.com/weJ1QsnbMYJlCHdG/arcgis/rest/services/Daily_Ports_Data/FeatureServer/0/query?f=json&where=portid+IN+%28%27port1188%27%2C%27port744%27%2C%27port815%27%2C%27port1114%27%2C%27port664%27%2C%27port1201%27%29+AND+date+%3E%3D+DATE+%272026-02-12%27+AND+date+%3C%3D+DATE+%272026-10-10%27&returnCountOnly=true",
    "retrieved_at": "2026-10-10T09:06:16.255671+00:00",
    "checksum": "ccd77a1a816f4122f66600bf5d7615e0bf69154490016b903e4a6ea0925e9d94",
    "raw_path": "data\\governance-final-20261010\\bronze\\portwatch_activity\\ccd77a1a816f4122f66600bf5d7615e0bf69154490016b903e4a6ea0925e9d94.raw",
    "bytes": 14,
    "duration_seconds": 0.786459399969317,
    "retries": 0,
    "status": "SUCCESS",
    "dataset_version": "sd2069_1720379017",
    "record_count": 0,
    "expected_extract_count": 1398,
    "source_name": "IMF PortWatch daily port activity",
    "schema_version": "1",
    "classification": "OBSERVED",
    "run_id": "0e73516a7329460684607b53d74b0f56"
  },
  {
    "acquisition_id": "9af03571fc39f58e773550da",
    "request_parameters": {
      "f": "json",
      "where": "portid IN ('port1188','port744','port815','port1114','port664','port1201') AND date >= DATE '2026-02-12' AND date <= DATE '2026-10-10'",
      "outFields": "*",
      "returnGeometry": "false",
      "orderByFields": "ObjectId",
      "resultOffset": 0,
      "resultRecordCount": 1000
    },
    "response_status": 200,
    "duplicate_payload": false,
    "source_timestamp": "Tue, 06 Oct 2026 18:41:27 GMT",
    "source_id": "portwatch_activity",
    "source_url": "https://services9.arcgis.com/weJ1QsnbMYJlCHdG/arcgis/rest/services/Daily_Ports_Data/FeatureServer/0/query?f=json&where=portid+IN+%28%27port1188%27%2C%27port744%27%2C%27port815%27%2C%27port1114%27%2C%27port664%27%2C%27port1201%27%29+AND+date+%3E%3D+DATE+%272026-02-12%27+AND+date+%3C%3D+DATE+%272026-10-10%27&outFields=%2A&returnGeometry=false&orderByFields=ObjectId&resultOffset=0&resultRecordCount=1000",
    "retrieved_at": "2026-10-10T09:06:18.200185+00:00",
    "checksum": "273d58055d94a51bcea629b60b5b85f571f3b27b4928a8f7456cb9f6859cf148",
    "raw_path": "data\\governance-final-20261010\\bronze\\portwatch_activity\\273d58055d94a51bcea629b60b5b85f571f3b27b4928a8f7456cb9f6859cf148.raw",
    "bytes": 625158,
    "duration_seconds": 1.9439166999654844,
    "retries": 0,
    "status": "SUCCESS",
    "dataset_version": "sd2069_1720379017",
    "record_count": 1000,
    "source_name": "IMF PortWatch daily port activity",
    "schema_version": "1",
    "classification": "OBSERVED",
    "run_id": "0e73516a7329460684607b53d74b0f56"
  },
  {
    "acquisition_id": "0cebfdcc31642255d0b44196",
    "request_parameters": {
      "f": "json",
      "where": "portid IN ('port1188','port744','port815','port1114','port664','port1201') AND date >= DATE '2026-02-12' AND date <= DATE '2026-10-10'",
      "outFields": "*",
      "returnGeometry": "false",
      "orderByFields": "ObjectId",
      "resultOffset": 1000,
      "resultRecordCount": 1000
    },
    "response_status": 200,
    "duplicate_payload": false,
    "source_timestamp": "Tue, 06 Oct 2026 18:41:27 GMT",
    "source_id": "portwatch_activity",
    "source_url": "https://services9.arcgis.com/weJ1QsnbMYJlCHdG/arcgis/rest/services/Daily_Ports_Data/FeatureServer/0/query?f=json&where=portid+IN+%28%27port1188%27%2C%27port744%27%2C%27port815%27%2C%27port1114%27%2C%27port664%27%2C%27port1201%27%29+AND+date+%3E%3D+DATE+%272026-02-12%27+AND+date+%3C%3D+DATE+%272026-10-10%27&outFields=%2A&returnGeometry=false&orderByFields=ObjectId&resultOffset=1000&resultRecordCount=1000",
    "retrieved_at": "2026-10-10T09:06:19.020009+00:00",
    "checksum": "58820aa8efed38707a28712197229fccf3b244943c2f379bf8b124cf2c19ce50",
    "raw_path": "data\\governance-final-20261010\\bronze\\portwatch_activity\\58820aa8efed38707a28712197229fccf3b244943c2f379bf8b124cf2c19ce50.raw",
    "bytes": 254420,
    "duration_seconds": 0.7798978999489918,
    "retries": 0,
    "status": "SUCCESS",
    "dataset_version": "sd2069_1720379017",
    "record_count": 398,
    "source_name": "IMF PortWatch daily port activity",
    "schema_version": "1",
    "classification": "OBSERVED",
    "run_id": "0e73516a7329460684607b53d74b0f56"
  },
  {
    "source_id": "portwatch_activity",
    "status": "CANONICALIZED",
    "retrieved_at": "2026-10-10T09:06:19.043964+00:00",
    "record_count": 1398,
    "accounting": {
      "input": 1398,
      "persisted_expected": 1398,
      "replaced_revision_window": 0,
      "filtered_expired": 0,
      "balanced": true
    },
    "source_name": "IMF PortWatch daily port activity",
    "source_url": "https://services9.arcgis.com/weJ1QsnbMYJlCHdG/arcgis/rest/services/Daily_Ports_Data/FeatureServer/0",
    "schema_version": "1",
    "classification": "OBSERVED",
    "dataset_version": null,
    "run_id": "0e73516a7329460684607b53d74b0f56"
  },
  {
    "acquisition_id": "668347ef73c756788a2e0ebe",
    "request_parameters": {
      "latitude": 31.19179536,
      "longitude": 121.6441968,
      "start_date": "2026-09-30",
      "end_date": "2026-10-05",
      "daily": "wind_speed_10m_max",
      "timezone": "UTC"
    },
    "response_status": 200,
    "duplicate_payload": false,
    "source_timestamp": null,
    "source_id": "weather",
    "source_url": "https://archive-api.open-meteo.com/v1/archive?latitude=31.19179536&longitude=121.6441968&start_date=2026-09-30&end_date=2026-10-05&daily=wind_speed_10m_max&timezone=UTC",
    "retrieved_at": "2026-10-10T09:06:19.558069+00:00",
    "checksum": "e8da3a2943b748bfb96057ea1f6a75f47f05ff66c6c75368ad5038574355a93e",
    "raw_path": "data\\governance-final-20261010\\bronze\\weather\\e8da3a2943b748bfb96057ea1f6a75f47f05ff66c6c75368ad5038574355a93e.raw",
    "bytes": 382,
    "duration_seconds": 0.5131333000026643,
    "retries": 0,
    "status": "SUCCESS",
    "dataset_version": null,
    "source_name": "Open-Meteo ERA5 historical reanalysis",
    "schema_version": "1",
    "classification": "DERIVED",
    "record_count": 0,
    "run_id": "0e73516a7329460684607b53d74b0f56"
  },
  {
    "acquisition_id": "bd515ba4a02d559e51b34ccf",
    "request_parameters": {
      "latitude": 24.99941947,
      "longitude": 55.07781687,
      "start_date": "2026-09-30",
      "end_date": "2026-10-05",
      "daily": "wind_speed_10m_max",
      "timezone": "UTC"
    },
    "response_status": 200,
    "duplicate_payload": false,
    "source_timestamp": null,
    "source_id": "weather",
    "source_url": "https://archive-api.open-meteo.com/v1/archive?latitude=24.99941947&longitude=55.07781687&start_date=2026-09-30&end_date=2026-10-05&daily=wind_speed_10m_max&timezone=UTC",
    "retrieved_at": "2026-10-10T09:06:19.685760+00:00",
    "checksum": "e491924ac28927af2b2dea7deda051f3261e3e186d6ce44782e74366691c4f64",
    "raw_path": "data\\governance-final-20261010\\bronze\\weather\\e491924ac28927af2b2dea7deda051f3261e3e186d6ce44782e74366691c4f64.raw",
    "bytes": 378,
    "duration_seconds": 0.12730359996203333,
    "retries": 0,
    "status": "SUCCESS",
    "dataset_version": null,
    "source_name": "Open-Meteo ERA5 historical reanalysis",
    "schema_version": "1",
    "classification": "DERIVED",
    "record_count": 0,
    "run_id": "0e73516a7329460684607b53d74b0f56"
  },
  {
    "acquisition_id": "adb1411d8005eb40f74a7048",
    "request_parameters": {
      "latitude": 40.63298387,
      "longitude": -74.17942126,
      "start_date": "2026-09-30",
      "end_date": "2026-10-05",
      "daily": "wind_speed_10m_max",
      "timezone": "UTC"
    },
    "response_status": 200,
    "duplicate_payload": false,
    "source_timestamp": null,
    "source_id": "weather",
    "source_url": "https://archive-api.open-meteo.com/v1/archive?latitude=40.63298387&longitude=-74.17942126&start_date=2026-09-30&end_date=2026-10-05&daily=wind_speed_10m_max&timezone=UTC",
    "retrieved_at": "2026-10-10T09:06:19.810513+00:00",
    "checksum": "0700f28f5992eaa8183bf339d0ac8524a61b5fa00b5aefd4a4484a8160364052",
    "raw_path": "data\\governance-final-20261010\\bronze\\weather\\0700f28f5992eaa8183bf339d0ac8524a61b5fa00b5aefd4a4484a8160364052.raw",
    "bytes": 378,
    "duration_seconds": 0.1254065000684932,
    "retries": 0,
    "status": "SUCCESS",
    "dataset_version": null,
    "source_name": "Open-Meteo ERA5 historical reanalysis",
    "schema_version": "1",
    "classification": "DERIVED",
    "record_count": 0,
    "run_id": "0e73516a7329460684607b53d74b0f56"
  },
  {
    "acquisition_id": "1a649da8a205e59d172c3c8b",
    "request_parameters": {
      "latitude": 51.92228121,
      "longitude": 4.215144967,
      "start_date": "2026-09-30",
      "end_date": "2026-10-05",
      "daily": "wind_speed_10m_max",
      "timezone": "UTC"
    },
    "response_status": 200,
    "duplicate_payload": false,
    "source_timestamp": null,
    "source_id": "weather",
    "source_url": "https://archive-api.open-meteo.com/v1/archive?latitude=51.92228121&longitude=4.215144967&start_date=2026-09-30&end_date=2026-10-05&daily=wind_speed_10m_max&timezone=UTC",
    "retrieved_at": "2026-10-10T09:06:19.937840+00:00",
    "checksum": "c6c68d30ad870e36344a7ae01705180056b3c5ea8bae5df7ce557de01bb4c524",
    "raw_path": "data\\governance-final-20261010\\bronze\\weather\\c6c68d30ad870e36344a7ae01705180056b3c5ea8bae5df7ce557de01bb4c524.raw",
    "bytes": 378,
    "duration_seconds": 0.12677079997956753,
    "retries": 0,
    "status": "SUCCESS",
    "dataset_version": null,
    "source_name": "Open-Meteo ERA5 historical reanalysis",
    "schema_version": "1",
    "classification": "DERIVED",
    "record_count": 0,
    "run_id": "0e73516a7329460684607b53d74b0f56"
  },
  {
    "acquisition_id": "7d7bf3713c9c6d4c4a8716b9",
    "request_parameters": {
      "latitude": 33.75569193,
      "longitude": -118.2437881,
      "start_date": "2026-09-30",
      "end_date": "2026-10-05",
      "daily": "wind_speed_10m_max",
      "timezone": "UTC"
    },
    "response_status": 200,
    "duplicate_payload": false,
    "source_timestamp": null,
    "source_id": "weather",
    "source_url": "https://archive-api.open-meteo.com/v1/archive?latitude=33.75569193&longitude=-118.2437881&start_date=2026-09-30&end_date=2026-10-05&daily=wind_speed_10m_max&timezone=UTC",
    "retrieved_at": "2026-10-10T09:06:20.065236+00:00",
    "checksum": "34c08f80a3c420f43df3c65a521f17347d01fa832aa05769417505a183ea6e26",
    "raw_path": "data\\governance-final-20261010\\bronze\\weather\\34c08f80a3c420f43df3c65a521f17347d01fa832aa05769417505a183ea6e26.raw",
    "bytes": 383,
    "duration_seconds": 0.12789390003308654,
    "retries": 0,
    "status": "SUCCESS",
    "dataset_version": null,
    "source_name": "Open-Meteo ERA5 historical reanalysis",
    "schema_version": "1",
    "classification": "DERIVED",
    "record_count": 0,
    "run_id": "0e73516a7329460684607b53d74b0f56"
  },
  {
    "acquisition_id": "a2c575323e3af18232b8e307",
    "request_parameters": {
      "latitude": 1.271989257,
      "longitude": 103.7074816,
      "start_date": "2026-09-30",
      "end_date": "2026-10-05",
      "daily": "wind_speed_10m_max",
      "timezone": "UTC"
    },
    "response_status": 200,
    "duplicate_payload": false,
    "source_timestamp": null,
    "source_id": "weather",
    "source_url": "https://archive-api.open-meteo.com/v1/archive?latitude=1.271989257&longitude=103.7074816&start_date=2026-09-30&end_date=2026-10-05&daily=wind_speed_10m_max&timezone=UTC",
    "retrieved_at": "2026-10-10T09:06:20.194848+00:00",
    "checksum": "7d4bcb41a8e8da36acc299064477764bd5cd8881131d0bd42bcac49cd21aa974",
    "raw_path": "data\\governance-final-20261010\\bronze\\weather\\7d4bcb41a8e8da36acc299064477764bd5cd8881131d0bd42bcac49cd21aa974.raw",
    "bytes": 380,
    "duration_seconds": 0.12843590008560568,
    "retries": 0,
    "status": "SUCCESS",
    "dataset_version": null,
    "source_name": "Open-Meteo ERA5 historical reanalysis",
    "schema_version": "1",
    "classification": "DERIVED",
    "record_count": 0,
    "run_id": "0e73516a7329460684607b53d74b0f56"
  }
]
```

## failures

```json
[]
```

## request_fingerprint

```json
"a3bda09701e464ae85cb8f48db1ee21af7caca98c144e4d481708abc24818ba9"
```

## governance

```json
{
  "contract_version": "1.0",
  "contract_fingerprint": "6f2853e4a8c2ec8371012e0704bf3b7c13eb1022817823ddf075dfbfe0912e8b",
  "configuration_fingerprint": "b2a23fd34be730fa93e49cde0922575c169155fbe310869fa3d57b7eb862b4d3",
  "code": {
    "git_commit": "2d02285b61c2b86fbebdcc8aa1b397bdcb92e3d0",
    "working_tree_dirty": false,
    "code_fingerprint": "2b336d78cca2e79d2d746523e5d570413285688db4ce41f43d4b2e4c45e40cd6",
    "python": "3.11.9",
    "dependencies": {
      "numpy": "2.4.6",
      "pandas": "2.3.3",
      "scikit-learn": "1.9.1",
      "pydantic": "2.13.5"
    }
  },
  "status": "PASS_WITH_WARNINGS",
  "scope": "LOCAL_ANALYTICAL",
  "stages": {
    "acquisition": {
      "status": "PASS_WITH_WARNINGS",
      "execution_id": "4fbfdc7989fb54e4d8d28183",
      "started_at": "2026-10-10T09:06:29.548119+00:00",
      "attempt": 1,
      "checks": {
        "nonempty_critical_sources": true,
        "registry_version": true,
        "source_failure_policy": true
      },
      "failed_rules": [],
      "warnings": [
        "REPLAY_NOT_LIVE",
        "OPTIONAL_SOURCE_UNAVAILABLE"
      ],
      "counts": {
        "received_ports": 6,
        "received_activity": 1398
      },
      "completed_at": "2026-10-10T09:06:29.633347+00:00",
      "duration_seconds": 0.08516690006945282
    },
    "bronze": {
      "status": "PASS",
      "execution_id": "308c978e724aeeeb1ae934a7",
      "started_at": "2026-10-10T09:06:29.658306+00:00",
      "attempt": 1,
      "checks": {
        "evidence_retained": true,
        "payload_hashes_verified": true
      },
      "failed_rules": [],
      "warnings": [],
      "counts": {
        "payloads": 1
      },
      "completed_at": "2026-10-10T09:06:29.691762+00:00",
      "duration_seconds": 0.03288309997878969
    },
    "silver": {
      "status": "PASS",
      "execution_id": "7261031a9aa7801faf45f636",
      "started_at": "2026-10-10T09:06:29.715052+00:00",
      "attempt": 1,
      "checks": {
        "canonical_dq": true,
        "record_accounting": true
      },
      "failed_rules": [],
      "warnings": [],
      "counts": {
        "received": 1434,
        "accepted": 1434,
        "rejected": 0,
        "quarantined": 0,
        "balanced": true
      },
      "completed_at": "2026-10-10T09:06:29.897978+00:00",
      "duration_seconds": 0.1830760999582708
    },
    "metrics": {
      "status": "PASS",
      "execution_id": "97eddd67492aa9084997c15f",
      "started_at": "2026-10-10T09:06:29.926770+00:00",
      "attempt": 1,
      "checks": {
        "independent_current_metrics": true,
        "port_coverage": true
      },
      "failed_rules": [],
      "warnings": [],
      "counts": {},
      "completed_at": "2026-10-10T09:06:30.858430+00:00",
      "duration_seconds": 0.9328879000386223
    },
    "scenario": {
      "status": "PASS",
      "execution_id": "bf3e845d0c397d9559135c18",
      "started_at": "2026-10-10T09:06:30.885193+00:00",
      "attempt": 1,
      "checks": {
        "shipment_action_accounting": true,
        "all_outputs_simulated": true
      },
      "failed_rules": [],
      "warnings": [],
      "counts": {},
      "completed_at": "2026-10-10T09:06:31.092639+00:00",
      "duration_seconds": 0.20694090006873012
    },
    "features_ml": {
      "status": "PASS_WITH_WARNINGS",
      "execution_id": "7c37c7d3f79696ebe384aefa",
      "started_at": "2026-10-10T09:06:31.126154+00:00",
      "attempt": 1,
      "checks": {
        "sla_not_trained": true,
        "prediction_classification": true
      },
      "failed_rules": [],
      "warnings": [
        "LOCAL_RESEARCH_MODEL"
      ],
      "counts": {
        "predictions": 6
      },
      "completed_at": "2026-10-10T09:06:33.397821+00:00",
      "duration_seconds": 2.2714965000050142
    },
    "gold": {
      "status": "PASS",
      "execution_id": "339c328d9d8b9326d97437e7",
      "started_at": "2026-10-10T09:06:33.418339+00:00",
      "attempt": 1,
      "checks": {
        "dataset_contracts_and_independent_checks": true
      },
      "failed_rules": [],
      "warnings": [],
      "counts": {
        "ports": {
          "input": 6,
          "persisted_expected": 6,
          "invalid": 0
        },
        "activity": {
          "input": 1398,
          "persisted_expected": 1398,
          "invalid": 0
        },
        "routes": {
          "input": 30,
          "persisted_expected": 30,
          "invalid": 0
        },
        "congestion_history": {
          "input": 1398,
          "persisted_expected": 1398,
          "invalid": 0
        },
        "congestion": {
          "input": 6,
          "persisted_expected": 6,
          "invalid": 0
        },
        "network": {
          "input": 30,
          "persisted_expected": 30,
          "invalid": 0
        },
        "exposure": {
          "input": 0,
          "persisted_expected": 0,
          "invalid": 0
        },
        "scenarios": {
          "input": 60,
          "persisted_expected": 60,
          "invalid": 0
        },
        "interventions": {
          "input": 300,
          "persisted_expected": 300,
          "invalid": 0
        },
        "sla_risk": {
          "input": 60,
          "persisted_expected": 60,
          "invalid": 0
        },
        "decisions": {
          "input": 60,
          "persisted_expected": 60,
          "invalid": 0
        },
        "predictions": {
          "input": 6,
          "persisted_expected": 6,
          "invalid": 0
        },
        "disruptions": {
          "input": 0,
          "persisted_expected": 0,
          "invalid": 0
        },
        "early_warning": {
          "input": 0,
          "persisted_expected": 0,
          "invalid": 0
        },
        "sources": {
          "input": 6,
          "persisted_expected": 6,
          "invalid": 0
        },
        "data_quality": {
          "input": 1,
          "persisted_expected": 1,
          "invalid": 0
        },
        "lineage": {
          "input": 215,
          "persisted_expected": 215,
          "invalid": 0
        },
        "dim_location": {
          "input": 6,
          "persisted_expected": 6,
          "invalid": 0
        },
        "dim_time": {
          "input": 233,
          "persisted_expected": 233,
          "invalid": 0
        },
        "dim_intervention": {
          "input": 5,
          "persisted_expected": 5,
          "invalid": 0
        }
      },
      "completed_at": "2026-10-10T09:06:34.146110+00:00",
      "duration_seconds": 0.7273784999269992
    },
    "publication": {
      "status": "PASS",
      "execution_id": "7c10b3b151a5db5baad4cfcd",
      "started_at": "2026-10-10T09:06:35.423795+00:00",
      "attempt": 1,
      "checks": {
        "persisted_readback": true,
        "audit_chain": true
      },
      "failed_rules": [],
      "warnings": [],
      "counts": {},
      "completed_at": "2026-10-10T09:06:35.839738+00:00",
      "duration_seconds": 0.41628419992048293
    }
  },
  "industrial_release": {
    "status": "BLOCKED",
    "unevaluated_mandatory_controls": [
      "fabric_runtime_and_readback",
      "azure_ml_lifecycle_and_return",
      "cloud_identity_and_least_privilege",
      "raw_and_audit_retention_enforcement",
      "production_slo_agreement_and_sustained_evidence"
    ]
  }
}
```

## execution_mode

```json
"REPLAY"
```

## as_of

```json
"2026-10-10"
```

## degraded_sources

```json
[
  "routes",
  "unlocode",
  "wpi"
]
```

## bronze_manifest

```json
[
  {
    "source_id": "replay_bundle",
    "checksum": "7b4ff7a402f605d450ad456339b30f3053138ec5bee2f9af8281e597e52c4df0",
    "scope": "NORMALIZED_REPLAY_NOT_LIVE_SOURCE"
  }
]
```

## data_quality

```json
{
  "status": "PASS",
  "records_processed": 1434,
  "records_rejected": 0,
  "accounting": {
    "received": 1434,
    "accepted": 1434,
    "rejected": 0,
    "quarantined": 0,
    "balanced": true
  },
  "dispositions": [
    {
      "table": "ports",
      "row": 0,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "ports",
      "row": 1,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "ports",
      "row": 2,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "ports",
      "row": 3,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "ports",
      "row": 4,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "ports",
      "row": 5,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 0,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 2,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 3,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 4,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 5,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 6,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 7,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 8,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 9,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 10,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 11,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 12,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 13,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 14,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 15,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 16,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 17,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 18,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 19,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 20,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 21,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 22,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 23,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 24,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 25,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 26,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 27,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 28,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 29,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 30,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 31,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 32,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 33,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 34,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 35,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 36,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 37,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 38,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 39,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 40,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 41,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 42,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 43,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 44,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 45,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 46,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 47,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 48,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 49,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 50,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 51,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 52,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 53,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 54,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 55,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 56,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 57,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 58,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 59,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 60,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 61,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 62,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 63,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 64,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 65,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 66,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 67,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 68,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 69,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 70,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 71,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 72,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 73,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 74,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 75,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 76,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 77,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 78,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 79,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 80,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 81,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 82,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 83,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 84,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 85,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 86,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 87,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 88,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 89,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 90,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 91,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 92,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 93,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 94,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 95,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 96,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 97,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 98,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 99,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 100,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 101,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 102,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 103,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 104,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 105,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 106,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 107,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 108,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 109,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 110,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 111,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 112,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 113,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 114,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 115,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 116,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 117,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 118,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 119,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 120,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 121,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 122,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 123,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 124,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 125,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 126,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 127,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 128,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 129,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 130,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 131,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 132,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 133,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 134,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 135,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 136,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 137,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 138,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 139,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 140,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 141,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 142,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 143,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 144,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 145,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 146,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 147,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 148,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 149,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 150,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 151,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 152,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 153,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 154,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 155,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 156,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 157,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 158,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 159,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 160,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 161,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 162,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 163,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 164,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 165,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 166,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 167,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 168,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 169,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 170,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 171,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 172,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 173,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 174,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 175,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 176,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 177,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 178,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 179,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 180,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 181,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 182,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 183,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 184,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 185,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 186,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 187,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 188,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 189,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 190,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 191,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 192,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 193,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 194,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 195,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 196,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 197,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 198,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 199,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 200,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 201,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 202,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 203,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 204,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 205,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 206,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 207,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 208,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 209,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 210,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 211,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 212,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 213,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 214,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 215,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 216,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 217,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 218,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 219,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 220,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 221,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 222,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 223,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 224,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 225,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 226,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 227,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 228,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 229,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 230,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 231,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 232,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 233,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 234,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 235,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 236,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 237,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 238,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 239,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 240,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 241,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 242,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 243,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 244,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 245,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 246,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 247,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 248,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 249,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 250,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 251,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 252,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 253,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 254,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 255,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 256,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 257,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 258,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 259,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 260,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 261,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 262,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 263,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 264,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 265,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 266,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 267,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 268,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 269,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 270,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 271,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 272,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 273,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 274,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 275,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 276,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 277,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 278,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 279,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 280,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 281,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 282,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 283,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 284,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 285,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 286,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 287,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 288,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 289,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 290,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 291,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 292,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 293,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 294,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 295,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 296,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 297,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 298,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 299,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 300,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 301,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 302,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 303,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 304,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 305,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 306,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 307,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 308,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 309,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 310,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 311,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 312,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 313,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 314,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 315,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 316,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 317,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 318,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 319,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 320,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 321,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 322,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 323,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 324,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 325,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 326,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 327,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 328,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 329,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 330,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 331,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 332,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 333,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 334,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 335,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 336,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 337,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 338,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 339,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 340,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 341,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 342,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 343,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 344,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 345,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 346,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 347,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 348,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 349,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 350,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 351,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 352,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 353,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 354,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 355,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 356,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 357,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 358,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 359,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 360,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 361,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 362,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 363,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 364,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 365,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 366,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 367,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 368,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 369,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 370,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 371,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 372,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 373,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 374,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 375,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 376,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 377,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 378,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 379,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 380,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 381,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 382,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 383,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 384,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 385,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 386,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 387,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 388,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 389,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 390,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 391,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 392,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 393,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 394,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 395,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 396,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 397,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 398,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 399,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 400,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 401,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 402,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 403,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 404,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 405,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 406,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 407,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 408,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 409,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 410,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 411,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 412,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 413,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 414,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 415,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 416,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 417,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 418,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 419,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 420,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 421,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 422,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 423,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 424,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 425,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 426,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 427,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 428,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 429,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 430,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 431,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 432,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 433,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 434,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 435,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 436,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 437,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 438,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 439,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 440,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 441,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 442,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 443,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 444,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 445,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 446,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 447,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 448,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 449,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 450,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 451,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 452,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 453,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 454,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 455,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 456,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 457,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 458,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 459,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 460,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 461,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 462,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 463,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 464,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 465,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 466,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 467,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 468,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 469,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 470,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 471,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 472,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 473,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 474,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 475,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 476,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 477,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 478,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 479,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 480,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 481,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 482,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 483,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 484,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 485,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 486,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 487,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 488,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 489,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 490,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 491,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 492,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 493,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 494,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 495,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 496,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 497,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 498,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 499,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 500,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 501,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 502,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 503,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 504,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 505,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 506,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 507,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 508,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 509,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 510,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 511,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 512,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 513,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 514,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 515,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 516,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 517,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 518,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 519,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 520,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 521,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 522,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 523,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 524,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 525,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 526,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 527,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 528,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 529,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 530,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 531,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 532,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 533,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 534,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 535,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 536,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 537,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 538,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 539,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 540,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 541,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 542,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 543,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 544,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 545,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 546,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 547,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 548,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 549,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 550,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 551,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 552,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 553,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 554,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 555,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 556,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 557,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 558,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 559,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 560,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 561,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 562,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 563,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 564,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 565,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 566,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 567,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 568,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 569,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 570,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 571,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 572,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 573,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 574,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 575,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 576,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 577,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 578,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 579,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 580,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 581,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 582,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 583,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 584,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 585,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 586,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 587,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 588,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 589,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 590,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 591,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 592,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 593,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 594,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 595,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 596,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 597,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 598,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 599,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 600,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 601,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 602,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 603,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 604,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 605,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 606,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 607,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 608,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 609,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 610,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 611,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 612,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 613,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 614,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 615,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 616,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 617,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 618,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 619,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 620,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 621,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 622,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 623,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 624,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 625,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 626,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 627,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 628,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 629,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 630,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 631,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 632,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 633,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 634,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 635,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 636,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 637,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 638,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 639,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 640,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 641,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 642,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 643,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 644,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 645,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 646,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 647,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 648,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 649,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 650,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 651,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 652,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 653,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 654,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 655,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 656,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 657,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 658,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 659,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 660,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 661,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 662,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 663,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 664,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 665,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 666,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 667,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 668,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 669,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 670,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 671,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 672,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 673,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 674,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 675,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 676,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 677,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 678,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 679,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 680,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 681,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 682,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 683,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 684,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 685,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 686,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 687,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 688,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 689,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 690,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 691,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 692,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 693,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 694,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 695,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 696,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 697,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 698,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 699,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 700,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 701,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 702,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 703,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 704,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 705,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 706,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 707,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 708,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 709,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 710,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 711,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 712,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 713,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 714,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 715,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 716,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 717,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 718,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 719,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 720,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 721,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 722,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 723,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 724,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 725,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 726,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 727,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 728,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 729,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 730,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 731,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 732,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 733,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 734,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 735,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 736,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 737,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 738,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 739,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 740,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 741,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 742,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 743,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 744,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 745,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 746,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 747,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 748,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 749,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 750,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 751,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 752,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 753,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 754,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 755,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 756,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 757,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 758,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 759,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 760,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 761,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 762,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 763,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 764,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 765,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 766,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 767,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 768,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 769,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 770,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 771,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 772,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 773,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 774,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 775,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 776,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 777,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 778,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 779,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 780,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 781,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 782,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 783,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 784,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 785,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 786,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 787,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 788,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 789,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 790,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 791,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 792,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 793,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 794,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 795,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 796,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 797,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 798,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 799,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 800,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 801,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 802,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 803,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 804,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 805,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 806,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 807,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 808,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 809,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 810,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 811,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 812,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 813,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 814,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 815,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 816,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 817,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 818,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 819,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 820,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 821,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 822,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 823,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 824,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 825,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 826,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 827,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 828,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 829,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 830,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 831,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 832,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 833,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 834,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 835,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 836,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 837,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 838,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 839,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 840,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 841,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 842,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 843,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 844,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 845,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 846,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 847,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 848,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 849,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 850,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 851,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 852,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 853,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 854,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 855,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 856,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 857,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 858,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 859,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 860,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 861,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 862,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 863,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 864,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 865,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 866,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 867,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 868,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 869,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 870,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 871,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 872,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 873,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 874,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 875,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 876,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 877,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 878,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 879,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 880,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 881,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 882,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 883,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 884,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 885,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 886,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 887,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 888,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 889,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 890,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 891,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 892,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 893,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 894,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 895,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 896,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 897,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 898,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 899,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 900,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 901,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 902,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 903,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 904,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 905,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 906,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 907,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 908,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 909,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 910,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 911,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 912,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 913,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 914,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 915,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 916,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 917,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 918,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 919,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 920,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 921,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 922,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 923,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 924,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 925,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 926,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 927,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 928,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 929,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 930,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 931,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 932,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 933,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 934,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 935,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 936,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 937,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 938,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 939,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 940,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 941,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 942,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 943,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 944,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 945,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 946,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 947,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 948,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 949,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 950,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 951,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 952,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 953,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 954,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 955,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 956,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 957,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 958,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 959,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 960,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 961,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 962,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 963,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 964,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 965,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 966,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 967,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 968,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 969,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 970,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 971,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 972,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 973,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 974,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 975,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 976,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 977,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 978,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 979,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 980,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 981,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 982,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 983,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 984,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 985,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 986,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 987,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 988,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 989,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 990,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 991,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 992,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 993,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 994,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 995,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 996,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 997,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 998,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 999,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1000,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1001,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1002,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1003,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1004,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1005,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1006,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1007,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1008,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1009,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1010,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1011,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1012,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1013,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1014,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1015,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1016,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1017,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1018,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1019,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1020,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1021,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1022,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1023,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1024,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1025,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1026,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1027,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1028,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1029,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1030,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1031,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1032,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1033,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1034,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1035,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1036,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1037,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1038,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1039,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1040,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1041,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1042,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1043,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1044,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1045,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1046,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1047,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1048,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1049,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1050,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1051,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1052,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1053,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1054,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1055,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1056,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1057,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1058,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1059,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1060,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1061,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1062,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1063,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1064,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1065,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1066,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1067,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1068,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1069,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1070,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1071,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1072,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1073,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1074,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1075,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1076,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1077,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1078,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1079,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1080,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1081,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1082,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1083,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1084,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1085,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1086,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1087,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1088,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1089,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1090,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1091,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1092,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1093,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1094,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1095,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1096,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1097,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1098,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1099,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1100,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1101,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1102,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1103,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1104,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1105,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1106,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1107,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1108,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1109,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1110,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1111,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1112,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1113,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1114,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1115,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1116,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1117,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1118,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1119,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1120,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1121,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1122,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1123,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1124,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1125,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1126,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1127,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1128,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1129,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1130,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1131,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1132,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1133,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1134,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1135,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1136,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1137,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1138,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1139,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1140,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1141,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1142,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1143,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1144,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1145,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1146,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1147,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1148,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1149,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1150,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1151,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1152,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1153,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1154,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1155,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1156,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1157,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1158,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1159,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1160,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1161,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1162,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1163,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1164,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1165,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1166,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1167,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1168,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1169,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1170,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1171,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1172,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1173,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1174,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1175,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1176,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1177,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1178,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1179,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1180,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1181,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1182,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1183,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1184,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1185,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1186,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1187,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1188,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1189,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1190,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1191,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1192,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1193,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1194,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1195,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1196,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1197,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1198,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1199,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1200,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1201,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1202,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1203,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1204,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1205,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1206,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1207,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1208,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1209,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1210,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1211,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1212,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1213,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1214,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1215,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1216,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1217,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1218,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1219,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1220,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1221,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1222,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1223,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1224,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1225,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1226,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1227,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1228,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1229,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1230,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1231,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1232,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1233,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1234,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1235,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1236,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1237,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1238,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1239,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1240,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1241,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1242,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1243,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1244,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1245,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1246,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1247,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1248,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1249,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1250,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1251,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1252,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1253,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1254,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1255,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1256,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1257,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1258,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1259,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1260,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1261,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1262,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1263,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1264,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1265,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1266,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1267,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1268,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1269,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1270,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1271,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1272,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1273,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1274,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1275,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1276,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1277,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1278,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1279,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1280,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1281,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1282,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1283,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1284,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1285,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1286,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1287,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1288,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1289,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1290,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1291,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1292,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1293,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1294,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1295,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1296,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1297,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1298,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1299,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1300,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1301,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1302,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1303,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1304,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1305,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1306,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1307,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1308,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1309,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1310,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1311,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1312,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1313,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1314,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1315,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1316,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1317,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1318,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1319,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1320,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1321,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1322,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1323,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1324,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1325,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1326,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1327,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1328,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1329,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1330,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1331,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1332,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1333,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1334,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1335,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1336,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1337,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1338,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1339,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1340,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1341,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1342,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1343,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1344,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1345,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1346,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1347,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1348,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1349,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1350,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1351,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1352,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1353,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1354,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1355,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1356,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1357,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1358,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1359,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1360,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1361,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1362,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1363,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1364,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1365,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1366,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1367,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1368,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1369,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1370,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1371,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1372,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1373,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1374,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1375,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1376,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1377,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1378,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1379,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1380,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1381,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1382,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1383,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1384,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1385,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1386,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1387,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1388,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1389,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1390,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1391,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1392,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1393,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1394,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1395,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1396,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "activity",
      "row": 1397,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 0,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 1,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 2,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 3,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 4,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 5,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 6,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 7,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 8,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 9,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 10,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 11,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 12,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 13,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 14,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 15,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 16,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 17,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 18,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 19,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 20,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 21,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 22,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 23,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 24,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 25,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 26,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 27,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 28,
      "status": "accepted",
      "reasons": []
    },
    {
      "table": "routes",
      "row": 29,
      "status": "accepted",
      "reasons": []
    }
  ],
  "completeness_rate": 1.0,
  "duplicate_rate": 0.0,
  "referential_integrity_rate": 1.0,
  "freshness_status": "PASS",
  "schema_status": "PASS",
  "cross_source_reconciliation": "NOT_CONFIGURED",
  "overall_dq_score": 1.0,
  "latest_by_port": {
    "port744": "2026-10-02",
    "port815": "2026-10-02",
    "port1201": "2026-10-02",
    "port1188": "2026-10-02",
    "port1114": "2026-10-02",
    "port664": "2026-10-02"
  },
  "history_counts": {
    "port1114": 233,
    "port1188": 233,
    "port1201": 233,
    "port664": 233,
    "port744": 233,
    "port815": 233
  },
  "errors": [],
  "classification": "DERIVED",
  "lineage_id": "db4db93434fcd6a14c8ca006bb3eacc4fca92bdb72fab4e3ecb001160c73ab13",
  "run_id": "0e73516a7329460684607b53d74b0f56",
  "contract_version": "1.0",
  "processed_at": "2026-10-10T09:06:28.625762+00:00",
  "configuration_fingerprint": "b2a23fd34be730fa93e49cde0922575c169155fbe310869fa3d57b7eb862b4d3",
  "component_classifications": [],
  "input_fingerprints": {},
  "degraded_sources": [
    "routes",
    "unlocode",
    "wpi"
  ],
  "execution_mode": "REPLAY"
}
```

## independent_metrics

```json
[
  {
    "port_id": "port1114",
    "date": "2026-10-02",
    "independent_baseline": 83.35714285714286,
    "independent_z_score": -0.034083075813000026,
    "passed": true
  },
  {
    "port_id": "port1188",
    "date": "2026-10-02",
    "independent_baseline": 79.42857142857143,
    "independent_z_score": -0.3428340143396546,
    "passed": true
  },
  {
    "port_id": "port1201",
    "date": "2026-10-02",
    "independent_baseline": 116.0,
    "independent_z_score": -0.6107556641289641,
    "passed": true
  },
  {
    "port_id": "port664",
    "date": "2026-10-02",
    "independent_baseline": 10.232142857142858,
    "independent_z_score": 0.5551033396334509,
    "passed": true
  },
  {
    "port_id": "port744",
    "date": "2026-10-02",
    "independent_baseline": 4.464285714285714,
    "independent_z_score": 1.3034656043534056,
    "passed": true
  },
  {
    "port_id": "port815",
    "date": "2026-10-02",
    "independent_baseline": 9.821428571428571,
    "independent_z_score": -0.8397130853781438,
    "passed": true
  }
]
```

## product_verification

```json
{
  "status": "PASS",
  "errors": [],
  "independent_metrics": [
    {
      "port_id": "port1114",
      "date": "2026-10-02",
      "independent_baseline": 83.35714285714286,
      "independent_z_score": -0.034083075813000026,
      "published_baseline": 83.35714285714286,
      "passed": true
    },
    {
      "port_id": "port1188",
      "date": "2026-10-02",
      "independent_baseline": 79.42857142857143,
      "independent_z_score": -0.3428340143396546,
      "published_baseline": 79.42857142857143,
      "passed": true
    },
    {
      "port_id": "port1201",
      "date": "2026-10-02",
      "independent_baseline": 116.0,
      "independent_z_score": -0.6107556641289641,
      "published_baseline": 116.0,
      "passed": true
    },
    {
      "port_id": "port664",
      "date": "2026-10-02",
      "independent_baseline": 10.232142857142858,
      "independent_z_score": 0.5551033396334509,
      "published_baseline": 10.232142857142858,
      "passed": true
    },
    {
      "port_id": "port744",
      "date": "2026-10-02",
      "independent_baseline": 4.464285714285714,
      "independent_z_score": 1.3034656043534056,
      "published_baseline": 4.464285714285714,
      "passed": true
    },
    {
      "port_id": "port815",
      "date": "2026-10-02",
      "independent_baseline": 9.821428571428571,
      "independent_z_score": -0.8397130853781438,
      "published_baseline": 9.821428571428571,
      "passed": true
    }
  ],
  "reconciliation": {
    "ports": {
      "input": 6,
      "persisted_expected": 6,
      "invalid": 0
    },
    "activity": {
      "input": 1398,
      "persisted_expected": 1398,
      "invalid": 0
    },
    "routes": {
      "input": 30,
      "persisted_expected": 30,
      "invalid": 0
    },
    "congestion_history": {
      "input": 1398,
      "persisted_expected": 1398,
      "invalid": 0
    },
    "congestion": {
      "input": 6,
      "persisted_expected": 6,
      "invalid": 0
    },
    "network": {
      "input": 30,
      "persisted_expected": 30,
      "invalid": 0
    },
    "exposure": {
      "input": 0,
      "persisted_expected": 0,
      "invalid": 0
    },
    "scenarios": {
      "input": 60,
      "persisted_expected": 60,
      "invalid": 0
    },
    "interventions": {
      "input": 300,
      "persisted_expected": 300,
      "invalid": 0
    },
    "sla_risk": {
      "input": 60,
      "persisted_expected": 60,
      "invalid": 0
    },
    "decisions": {
      "input": 60,
      "persisted_expected": 60,
      "invalid": 0
    },
    "predictions": {
      "input": 6,
      "persisted_expected": 6,
      "invalid": 0
    },
    "disruptions": {
      "input": 0,
      "persisted_expected": 0,
      "invalid": 0
    },
    "early_warning": {
      "input": 0,
      "persisted_expected": 0,
      "invalid": 0
    },
    "sources": {
      "input": 6,
      "persisted_expected": 6,
      "invalid": 0
    },
    "data_quality": {
      "input": 1,
      "persisted_expected": 1,
      "invalid": 0
    },
    "lineage": {
      "input": 215,
      "persisted_expected": 215,
      "invalid": 0
    },
    "dim_location": {
      "input": 6,
      "persisted_expected": 6,
      "invalid": 0
    },
    "dim_time": {
      "input": 233,
      "persisted_expected": 233,
      "invalid": 0
    },
    "dim_intervention": {
      "input": 5,
      "persisted_expected": 5,
      "invalid": 0
    }
  }
}
```

## data

```json
{
  "records_ingested": 1404,
  "records_rejected": 0,
  "dq_score": 1.0,
  "freshness": "PASS"
}
```

## congestion

```json
{
  "ports_evaluated": 6,
  "categories": {
    "NORMAL": 5,
    "ELEVATED": 1
  },
  "persistence_days": {
    "port1114": 0,
    "port1188": 0,
    "port1201": 0,
    "port664": 0,
    "port744": 1,
    "port815": 0
  }
}
```

## network

```json
{
  "nodes": 6,
  "edges": 30,
  "affected_nodes": 0,
  "affected_edges": 0,
  "propagation_depth": 0,
  "propagation_results": 0,
  "topology": "SIMULATED_CONNECTIVITY",
  "alternative_routes": 60
}
```

## scenarios

```json
{
  "shipments": 60,
  "executions": 300,
  "success": 300,
  "failures": 0,
  "infeasible": 60,
  "seed": 1729
}
```

## sla

```json
{
  "at_risk_shipments": 11,
  "expected_delay_hours": 14.31328282012678,
  "expected_breaches": 11.666015625,
  "expected_loss": 42086.61221950587,
  "classification": "SIMULATED"
}
```

## counterfactual

```json
{
  "NO_ACTION": {
    "evaluated": 60,
    "feasible": 60
  },
  "REROUTE": {
    "evaluated": 60,
    "feasible": 60
  },
  "ALTERNATE_PORT": {
    "evaluated": 60,
    "feasible": 0
  },
  "EXPEDITE": {
    "evaluated": 60,
    "feasible": 60
  },
  "PRIORITIZE": {
    "evaluated": 60,
    "feasible": 60
  }
}
```

## decision

```json
{
  "recommendations": {
    "NO_ACTION": 48,
    "EXPEDITE": 6,
    "PRIORITIZE": 6
  },
  "count": 60,
  "expected_benefit": 11907.05846402094,
  "expected_delay_avoided": 139.67245137362414,
  "decision_confidence": "NOT_CALIBRATED",
  "operator_overrides": 0
}
```

## ml

```json
{
  "status": "VALIDATED_TEMPORAL_HOLDOUT",
  "target": "next-day vessel_calls",
  "training_records": 948,
  "calibration_records": 204,
  "validation_records": 204,
  "model": "forest_4",
  "model_version": "46cf59d43e484752bf153a02",
  "feature_version": "portcalls-lags-v1",
  "features": [
    "lag1",
    "lag7",
    "mean7",
    "std7",
    "day_of_week"
  ],
  "dataset_version": "b967799c318ca1788f4ba942",
  "training_start": "2026-02-19",
  "training_end": "2026-07-26",
  "calibration_start": "2026-07-27",
  "calibration_end": "2026-08-29",
  "validation_start": "2026-08-30",
  "validation_end": "2026-10-02",
  "metrics": {
    "mae": 5.92282571981091,
    "rmse": 8.529662901267663,
    "persistence_mae": 8.215686274509803
  },
  "calibration": {
    "method": "split conformal absolute residual",
    "nominal_coverage": 0.9,
    "empirical_holdout_coverage": 0.9362745098039216,
    "radius": 18.287951404015786,
    "caveat": "Temporal dependence invalidates exchangeability guarantees"
  },
  "drift": {
    "standardized_mean_shift": {
      "lag1": 0.07225081569898101,
      "lag7": 0.08194106299589475,
      "mean7": 0.08280179744468062,
      "std7": 0.08209279900842918,
      "day_of_week": 0.048484637940249674
    },
    "alert": false
  },
  "comparisons": [
    {
      "name": "persistence",
      "mae": 8.643274853801168,
      "folds": [
        {
          "train_end": "2026-05-08",
          "validation_start": "2026-05-09",
          "validation_end": "2026-05-27",
          "mae": 10.859649122807017
        },
        {
          "train_end": "2026-05-31",
          "validation_start": "2026-06-01",
          "validation_end": "2026-06-19",
          "mae": 6.271929824561403
        },
        {
          "train_end": "2026-06-24",
          "validation_start": "2026-06-25",
          "validation_end": "2026-07-13",
          "mae": 8.798245614035087
        }
      ]
    },
    {
      "name": "ridge_1",
      "mae": 6.785392523948921,
      "folds": [
        {
          "train_end": "2026-05-08",
          "validation_start": "2026-05-09",
          "validation_end": "2026-05-27",
          "mae": 7.684440885632631
        },
        {
          "train_end": "2026-05-31",
          "validation_start": "2026-06-01",
          "validation_end": "2026-06-19",
          "mae": 4.777098257660947
        },
        {
          "train_end": "2026-06-24",
          "validation_start": "2026-06-25",
          "validation_end": "2026-07-13",
          "mae": 7.894638428553184
        }
      ]
    },
    {
      "name": "ridge_10",
      "mae": 6.893528966896053,
      "folds": [
        {
          "train_end": "2026-05-08",
          "validation_start": "2026-05-09",
          "validation_end": "2026-05-27",
          "mae": 7.782239707010521
        },
        {
          "train_end": "2026-05-31",
          "validation_start": "2026-06-01",
          "validation_end": "2026-06-19",
          "mae": 5.148164845157437
        },
        {
          "train_end": "2026-06-24",
          "validation_start": "2026-06-25",
          "validation_end": "2026-07-13",
          "mae": 7.750182348520201
        }
      ]
    },
    {
      "name": "forest_4",
      "mae": 6.769886903558155,
      "folds": [
        {
          "train_end": "2026-05-08",
          "validation_start": "2026-05-09",
          "validation_end": "2026-05-27",
          "mae": 7.40034351456276
        },
        {
          "train_end": "2026-05-31",
          "validation_start": "2026-06-01",
          "validation_end": "2026-06-19",
          "mae": 5.038851724694307
        },
        {
          "train_end": "2026-06-24",
          "validation_start": "2026-06-25",
          "validation_end": "2026-07-13",
          "mae": 7.870465471417398
        }
      ]
    },
    {
      "name": "forest_8",
      "mae": 6.846648897369749,
      "folds": [
        {
          "train_end": "2026-05-08",
          "validation_start": "2026-05-09",
          "validation_end": "2026-05-27",
          "mae": 7.343604201825057
        },
        {
          "train_end": "2026-05-31",
          "validation_start": "2026-06-01",
          "validation_end": "2026-06-19",
          "mae": 5.422788932488448
        },
        {
          "train_end": "2026-06-24",
          "validation_start": "2026-06-25",
          "validation_end": "2026-07-13",
          "mae": 7.773553557795742
        }
      ]
    }
  ],
  "selection_rationale": "Lowest mean expanding-window MAE before calibration and untouched holdout",
  "hyperparameters": {
    "bootstrap": true,
    "ccp_alpha": 0.0,
    "criterion": "squared_error",
    "max_depth": 4,
    "max_features": 1.0,
    "max_leaf_nodes": null,
    "max_samples": null,
    "min_impurity_decrease": 0.0,
    "min_samples_leaf": 5,
    "min_samples_split": 2,
    "min_weight_fraction_leaf": 0.0,
    "monotonic_cst": null,
    "n_estimators": 80,
    "n_jobs": 1,
    "oob_score": false,
    "random_state": 1729,
    "verbose": 0,
    "warm_start": false
  },
  "error_analysis": {
    "port1114": 8.524472074753014,
    "port1188": 9.323438607308242,
    "port1201": 10.078134467414323,
    "port664": 2.739588374837831,
    "port744": 1.9414824709728615,
    "port815": 2.929838323579194
  },
  "duration_seconds": 2.0998621000908315,
  "sla_model_status": "DEFERRED \u2014 INSUFFICIENT OBSERVED OUTCOME DATA"
}
```

## genai

```json
{
  "status": "NOT_CONFIGURED_OR_EXECUTED",
  "signals_processed": 0,
  "verified": 0,
  "rejected": 0,
  "grounding_rate": null
}
```

## gates

```json
{
  "data_foundation": "PASS_EXECUTION",
  "data_platform": "PASS_EXECUTION",
  "congestion": "PASS_EXECUTION",
  "network": "PASS_EXECUTION",
  "scenario": "PASS_EXECUTION",
  "counterfactual": "PASS_EXECUTION",
  "sla": "PASS_EXECUTION",
  "ml": "VALIDATED_TEMPORAL_HOLDOUT",
  "decision": "PASS_EXECUTION_HUMAN_REVIEW_PENDING",
  "api_bi": "MARTS_EXPORTED_API_TEST_REQUIRED",
  "reliability": "TEST_EVIDENCE_REQUIRED",
  "e2e": "PASS_LOCAL_PIPELINE",
  "fabric": "ENVIRONMENT_DEPENDENT_NOT_VALIDATED"
}
```

## release

```json
{
  "contract_version": "1.0",
  "run_id": "0e73516a7329460684607b53d74b0f56",
  "release_id": "5665ed59fdd3af672b5932618ab620bb91b15ef50fdc7364cd1d94710fc4ec0c",
  "status": "PASS_WITH_WARNINGS",
  "scope": "LOCAL_ANALYTICAL",
  "execution_mode": "REPLAY",
  "as_of": "2026-10-10",
  "source_latest_by_port": {
    "port744": "2026-10-02",
    "port815": "2026-10-02",
    "port1201": "2026-10-02",
    "port1188": "2026-10-02",
    "port1114": "2026-10-02",
    "port664": "2026-10-02"
  },
  "approved_at": "2026-10-10T09:06:35.517238+00:00",
  "code": {
    "git_commit": "2d02285b61c2b86fbebdcc8aa1b397bdcb92e3d0",
    "working_tree_dirty": false,
    "code_fingerprint": "2b336d78cca2e79d2d746523e5d570413285688db4ce41f43d4b2e4c45e40cd6",
    "python": "3.11.9",
    "dependencies": {
      "numpy": "2.4.6",
      "pandas": "2.3.3",
      "scikit-learn": "1.9.1",
      "pydantic": "2.13.5"
    }
  },
  "contract_fingerprint": "6f2853e4a8c2ec8371012e0704bf3b7c13eb1022817823ddf075dfbfe0912e8b",
  "stage_evidence": {
    "acquisition": {
      "status": "PASS_WITH_WARNINGS",
      "execution_id": "4fbfdc7989fb54e4d8d28183",
      "started_at": "2026-10-10T09:06:29.548119+00:00",
      "attempt": 1,
      "checks": {
        "nonempty_critical_sources": true,
        "registry_version": true,
        "source_failure_policy": true
      },
      "failed_rules": [],
      "warnings": [
        "REPLAY_NOT_LIVE",
        "OPTIONAL_SOURCE_UNAVAILABLE"
      ],
      "counts": {
        "received_ports": 6,
        "received_activity": 1398
      },
      "completed_at": "2026-10-10T09:06:29.633347+00:00",
      "duration_seconds": 0.08516690006945282
    },
    "bronze": {
      "status": "PASS",
      "execution_id": "308c978e724aeeeb1ae934a7",
      "started_at": "2026-10-10T09:06:29.658306+00:00",
      "attempt": 1,
      "checks": {
        "evidence_retained": true,
        "payload_hashes_verified": true
      },
      "failed_rules": [],
      "warnings": [],
      "counts": {
        "payloads": 1
      },
      "completed_at": "2026-10-10T09:06:29.691762+00:00",
      "duration_seconds": 0.03288309997878969
    },
    "silver": {
      "status": "PASS",
      "execution_id": "7261031a9aa7801faf45f636",
      "started_at": "2026-10-10T09:06:29.715052+00:00",
      "attempt": 1,
      "checks": {
        "canonical_dq": true,
        "record_accounting": true
      },
      "failed_rules": [],
      "warnings": [],
      "counts": {
        "received": 1434,
        "accepted": 1434,
        "rejected": 0,
        "quarantined": 0,
        "balanced": true
      },
      "completed_at": "2026-10-10T09:06:29.897978+00:00",
      "duration_seconds": 0.1830760999582708
    },
    "metrics": {
      "status": "PASS",
      "execution_id": "97eddd67492aa9084997c15f",
      "started_at": "2026-10-10T09:06:29.926770+00:00",
      "attempt": 1,
      "checks": {
        "independent_current_metrics": true,
        "port_coverage": true
      },
      "failed_rules": [],
      "warnings": [],
      "counts": {},
      "completed_at": "2026-10-10T09:06:30.858430+00:00",
      "duration_seconds": 0.9328879000386223
    },
    "scenario": {
      "status": "PASS",
      "execution_id": "bf3e845d0c397d9559135c18",
      "started_at": "2026-10-10T09:06:30.885193+00:00",
      "attempt": 1,
      "checks": {
        "shipment_action_accounting": true,
        "all_outputs_simulated": true
      },
      "failed_rules": [],
      "warnings": [],
      "counts": {},
      "completed_at": "2026-10-10T09:06:31.092639+00:00",
      "duration_seconds": 0.20694090006873012
    },
    "features_ml": {
      "status": "PASS_WITH_WARNINGS",
      "execution_id": "7c37c7d3f79696ebe384aefa",
      "started_at": "2026-10-10T09:06:31.126154+00:00",
      "attempt": 1,
      "checks": {
        "sla_not_trained": true,
        "prediction_classification": true
      },
      "failed_rules": [],
      "warnings": [
        "LOCAL_RESEARCH_MODEL"
      ],
      "counts": {
        "predictions": 6
      },
      "completed_at": "2026-10-10T09:06:33.397821+00:00",
      "duration_seconds": 2.2714965000050142
    },
    "gold": {
      "status": "PASS",
      "execution_id": "339c328d9d8b9326d97437e7",
      "started_at": "2026-10-10T09:06:33.418339+00:00",
      "attempt": 1,
      "checks": {
        "dataset_contracts_and_independent_checks": true
      },
      "failed_rules": [],
      "warnings": [],
      "counts": {
        "ports": {
          "input": 6,
          "persisted_expected": 6,
          "invalid": 0
        },
        "activity": {
          "input": 1398,
          "persisted_expected": 1398,
          "invalid": 0
        },
        "routes": {
          "input": 30,
          "persisted_expected": 30,
          "invalid": 0
        },
        "congestion_history": {
          "input": 1398,
          "persisted_expected": 1398,
          "invalid": 0
        },
        "congestion": {
          "input": 6,
          "persisted_expected": 6,
          "invalid": 0
        },
        "network": {
          "input": 30,
          "persisted_expected": 30,
          "invalid": 0
        },
        "exposure": {
          "input": 0,
          "persisted_expected": 0,
          "invalid": 0
        },
        "scenarios": {
          "input": 60,
          "persisted_expected": 60,
          "invalid": 0
        },
        "interventions": {
          "input": 300,
          "persisted_expected": 300,
          "invalid": 0
        },
        "sla_risk": {
          "input": 60,
          "persisted_expected": 60,
          "invalid": 0
        },
        "decisions": {
          "input": 60,
          "persisted_expected": 60,
          "invalid": 0
        },
        "predictions": {
          "input": 6,
          "persisted_expected": 6,
          "invalid": 0
        },
        "disruptions": {
          "input": 0,
          "persisted_expected": 0,
          "invalid": 0
        },
        "early_warning": {
          "input": 0,
          "persisted_expected": 0,
          "invalid": 0
        },
        "sources": {
          "input": 6,
          "persisted_expected": 6,
          "invalid": 0
        },
        "data_quality": {
          "input": 1,
          "persisted_expected": 1,
          "invalid": 0
        },
        "lineage": {
          "input": 215,
          "persisted_expected": 215,
          "invalid": 0
        },
        "dim_location": {
          "input": 6,
          "persisted_expected": 6,
          "invalid": 0
        },
        "dim_time": {
          "input": 233,
          "persisted_expected": 233,
          "invalid": 0
        },
        "dim_intervention": {
          "input": 5,
          "persisted_expected": 5,
          "invalid": 0
        }
      },
      "completed_at": "2026-10-10T09:06:34.146110+00:00",
      "duration_seconds": 0.7273784999269992
    }
  },
  "configuration_fingerprint": "b2a23fd34be730fa93e49cde0922575c169155fbe310869fa3d57b7eb862b4d3",
  "datasets": {
    "ports": {
      "rows": 6,
      "sha256": "0c6f9f207f9cda8402728c2943e6077edef329a479d61ab798ffe08205f1978d",
      "classifications": [
        "OBSERVED"
      ]
    },
    "activity": {
      "rows": 1398,
      "sha256": "0131efaf3b779fe9c0cac41f25b4e9fd409d871590d94ad07be48641e56587a8",
      "classifications": [
        "OBSERVED"
      ]
    },
    "routes": {
      "rows": 30,
      "sha256": "127870f274dea74cfa093e0cc124bf4a118fc748011e3a59fc15001865f527c6",
      "classifications": [
        "SIMULATED"
      ]
    },
    "congestion_history": {
      "rows": 1398,
      "sha256": "70e0860d196c5c8eda0a6fdc2b79e5a3661eef451e9502cdcd17a516a2258aa6",
      "classifications": [
        "DERIVED"
      ]
    },
    "congestion": {
      "rows": 6,
      "sha256": "c2e65c14add5c3cebd15a76f6455cd746f9d55934ce8567b63ccec242ea85c7b",
      "classifications": [
        "DERIVED"
      ]
    },
    "network": {
      "rows": 30,
      "sha256": "7260ed27e89353d45febf22bc0f463aa22794d9695e7973703f6babc5137aeaa",
      "classifications": [
        "SIMULATED"
      ]
    },
    "exposure": {
      "rows": 0,
      "sha256": "4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945",
      "classifications": []
    },
    "scenarios": {
      "rows": 60,
      "sha256": "8766f937cf1fdb4efadccc85620cc8840c252c0d19da11dcb944ffe9ec4a982b",
      "classifications": [
        "SIMULATED"
      ]
    },
    "interventions": {
      "rows": 300,
      "sha256": "52e084fd503b65d3a87502e8bcdf28f3732b9072a91c39211aa43ccbc0bae0cb",
      "classifications": [
        "SIMULATED"
      ]
    },
    "sla_risk": {
      "rows": 60,
      "sha256": "070ccbd0cfd20d856c6ef90a34bb708e96a1c77aa115cd35a30a0a2e2cc8df62",
      "classifications": [
        "SIMULATED"
      ]
    },
    "decisions": {
      "rows": 60,
      "sha256": "3ed75c3458298fa561294c49aa91ef97dc411b839c9ee8da834a6ae668c59a70",
      "classifications": [
        "SIMULATED"
      ]
    },
    "predictions": {
      "rows": 6,
      "sha256": "9a03267f76924916bf5f1fa92227012f68728b8785741f8854de420bf3734d2d",
      "classifications": [
        "PREDICTED"
      ]
    },
    "disruptions": {
      "rows": 0,
      "sha256": "4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945",
      "classifications": []
    },
    "early_warning": {
      "rows": 0,
      "sha256": "4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945",
      "classifications": []
    },
    "sources": {
      "rows": 6,
      "sha256": "64103f7b9640934e51e6d05821029c2640c5fb31848694fc87b7116b5e2ea029",
      "classifications": [
        "DERIVED"
      ]
    },
    "data_quality": {
      "rows": 1,
      "sha256": "d44b204ae9cb4b1de8f6aa4fa76b734a71f3a99d331af97e9b196b1e85b4e673",
      "classifications": [
        "DERIVED"
      ]
    },
    "lineage": {
      "rows": 215,
      "sha256": "5ba198f06cc21fd037b11beeb6257e954f6871d7211e8e05aa6c47bf1729daa9",
      "classifications": [
        "DERIVED"
      ]
    },
    "dim_location": {
      "rows": 6,
      "sha256": "90097af8e4ce5c967172f6b893e8db2116292780ca6e342104aa63e05cd120a9",
      "classifications": [
        "OBSERVED"
      ]
    },
    "dim_time": {
      "rows": 233,
      "sha256": "2c94cb1febfa10f40f1493509ede3f851df3b42046c6a5b717cdea97617c47b1",
      "classifications": [
        "DERIVED"
      ]
    },
    "dim_intervention": {
      "rows": 5,
      "sha256": "c35de26ce786e7b5a10b1fc82f1f6dab6b48706d347617a40a36408fe40c9afb",
      "classifications": [
        "SIMULATED"
      ]
    }
  },
  "industrial_release": {
    "status": "BLOCKED",
    "unevaluated_mandatory_controls": [
      "fabric_runtime_and_readback",
      "azure_ml_lifecycle_and_return",
      "cloud_identity_and_least_privilege",
      "raw_and_audit_retention_enforcement",
      "production_slo_agreement_and_sustained_evidence"
    ]
  }
}
```

## end_time

```json
"2026-10-10T09:06:35.852232+00:00"
```

## reliability

```json
{
  "failures": 0,
  "retries": 0,
  "timeouts": 0,
  "recoveries": 0
}
```

## duration_seconds

```json
6.304066400043666
```